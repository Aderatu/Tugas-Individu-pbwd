<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mahasiswa</title>
</head>
<body>
    <h1>INI HALAMAN PROGRAM STUDI</h1>

    <h4>Halaman Tabel Program Studi</h4>
    <a href="/prodi/create">Tambah Program Studi</a>

<!-- INI CONTOH TABLE -->
    <table border="1" style="border-collapse: collapse;">
        <thead style="background-color: yellow;">
            <tr>
                <th>Nama Prodi</th>
                <th>Fakultas</th>
                <th>Kaprodi</th>
                <th>Sekprodi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($prd as $p)
            <tr>
                <td>{{ $m->nama_prodi}}</td>
                <td>{{$m->fakultas}}</td>
                <td>{{$m->kaprodi}}</td>
                <td>{{$m->sekprodi}}</td>
            </tr>
                
            @endforeach
        </tbody>
    </table>
    <form action="" method="get"></form>
</body>
</html>